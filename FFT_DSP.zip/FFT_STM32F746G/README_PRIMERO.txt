LABORATORIO 3 - FFT EN STM32F746G-DISCO
Proyecto de STM32CubeIDE basado en el laboratorio anterior adjuntado por el usuario.

DESTINO DESEADO EN WINDOWS
C:\Users\USUARIO\Documents\DSP\FFT\FFT_STM32F746G

1. EXTRAER E IMPORTAR
- Descomprima FFT_STM32F746G.zip dentro de:
  C:\Users\USUARIO\Documents\DSP\FFT
- Debera quedar una carpeta FFT_STM32F746G que contiene .project, .cproject,
  Core, Drivers, Utilities, FFT_STM32F746G.ioc y los archivos .ld.
- Abra STM32CubeIDE > File > Import > General > Existing Projects into Workspace.
- Seleccione la carpeta ...\DSP\FFT como directorio de busqueda.
- Importe el proyecto FFT_STM32F746G.
- Build Project; conecte la STM32F746G-DISCO con ST-LINK y utilice Run.

2. ARCHIVO PRINCIPAL
Core/Src/main.c
  Este es el UNICO archivo editado con la logica del laboratorio:
  generacion de senales, FFT, ventanas, deteccion de picos, menu y graficas.
  Los demas archivos son HAL, CMSIS base, BSP LCD y fuentes de caracteres.

3. COMO SE USA EN LA TARJETA
Unico pulsador USER/KEY de la STM32F746G-DISCO:
  MENU: pulsacion corta (<750 ms) cambia la senal seleccionada.
  MENU: pulsacion larga (>=750 ms) abre la senal.
  RESULTADOS: pulsacion corta alterna entre estas 4 vistas:
    1) Senal en el dominio del tiempo.
    2) Espectro con ventana rectangular.
    3) Espectro con ventana Hann.
    4) Diagnostico de los tres picos dominantes.
  RESULTADOS: pulsacion larga vuelve al menu.
El LED LD1 se activa mientras se revisan los resultados.

4. SENAL PROCESADA
  N=1024 muestras
  Fs=2048 Hz
  Delta f = Fs/N = 2 Hz
  Duracion de ventana = 0.5 s
  Frecuencia maxima representada = 350 Hz
  Eje vertical del espectro en amplitud lineal (unidades de senal).
  Se calculan 512 bins positivos de una FFT de 1024 puntos.

Se incluyen estos 7 casos:
  - Seno 100 Hz, amplitud 5.
  - Cuadrada 100 Hz, amplitud 5.
  - Triangular 100 Hz, amplitud 5.
  - Diente de sierra 100 Hz, amplitud 5.
  - Suma de 3 cuadradas: 100 Hz / 5; 50 Hz / 2; 80 Hz / 3.5.
  - Suma de 3 senos con las mismas frecuencias y amplitudes.
  - Seno 103 Hz / 5 para comparar fuga espectral con las dos ventanas.

La senal es SINTETICA, tal como el ejemplo de la guia: NO se mide por ADC.

5. DIFERENCIAS IMPORTANTES CON LA GUIA ORIGINAL
- NO hay TouchGFX: la interfaz se dibuja directamente en la pantalla
  por medio del BSP_LCD de ST que ya venia en su proyecto de referencia.
- La FFT se ejecuta con un algoritmo Cooley-Tukey radix-2 en C DENTRO de
  main.c, no con arm_rfft_fast_f32 de CMSIS-DSP. Lo anterior evita depender
  del archivo libarm_cortexM7lfsp_math.a, que NO vino con los adjuntos.
  SI el docente exige especificamente la API de CMSIS-DSP, se debera
  incorporar una biblioteca compatible y sustituir la rutina FFT_Radix2.
- Se conservan HAL, BSP y la inicializacion SDRAM/LCD/MPU del proyecto anterior.
- El archivo .ioc conserva configuraciones antiguas de ADC1 de la base;
  NO oprima Generate Code desde CubeMX sin respaldar antes main.c, pues la
  regeneracion puede sobreescribir funciones personalizadas.

6. COMPROBACIONES REALIZADAS
- Sintaxis de main.c y stm32f7xx_it.c comprobada con clang.
- Algoritmo FFT verificado en compilacion de prueba para PC (gcc).
- Tres picos del caso 3 cuadradas observados:
  100 Hz A~6.366; 80 Hz A~4.457; 50 Hz A~2.546.
- Picos en caso 3 senos: 100 Hz A~5; 80 Hz A~3.5; 50 Hz A~2.
- NO se realizo compilacion ARM final ni programacion fisica de la tarjeta
  STM32F746G-DISCO. Esa verificacion debe hacerse en STM32CubeIDE.

NOTA:
Si ve errores de importacion, confirme que se esta importando la carpeta
que contiene .project y .cproject; no abra main.c como un proyecto aislado.
