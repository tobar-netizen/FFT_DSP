/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stm32746g_discovery_lcd.h"
#include "stm32746g_discovery.h"
#include <math.h>
#include <stdio.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* Se conserva el simbolo porque stm32f7xx_it.c heredado referencia hadc1.
   ADC1 no se inicializa ni se utiliza en la practica FFT. */
ADC_HandleTypeDef hadc1;

/* USER CODE BEGIN PV */
volatile uint8_t lcd_init_status = 0xFFU;
volatile uint32_t startup_stage = 0U;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MPU_Config(void);
static void MX_GPIO_Init(void);
static void App_Init(void);
static void App_Update(uint32_t time_ms);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* --------------------------------------------------------------------------
 * LABORATORIO 3 - FFT en STM32F746G-DISCO
 * TODA la logica de senales, FFT y pantalla reside en este archivo main.c.
 * Usa HAL y el BSP LCD de ST como controladores (no requiere TouchGFX).
 *
 * Especificaciones de la guia: FFT=1024, Fs=2048 Hz, df=2 Hz,
 * grafica de 0 a 350 Hz, senales SINE/SQUARE/TRIANGLE/SAWTOOTH.
 *
 * NOTA: FFT radix-2 en C para que el proyecto compile sin enlazar la libreria
 * CMSIS-DSP precompilada que la guia pide descargar por separado. El resultado
 * matematico es equivalente a la FFT; NO se llama a arm_rfft_fast_f32.
 * -------------------------------------------------------------------------- */
#define FFT_SIZE                 1024U
#define SAMPLE_RATE_HZ           2048.0f
#define SPECTRUM_LIMIT_HZ        350.0f
#define TIME_PLOT_SAMPLES       256U
#define PI_F                    3.14159265358979323846f
#define CASE_COUNT              7U
#define VIEW_COUNT              4U
#define DEBOUNCE_MS             40U
#define HOLD_MS                 750U
#define GRAPH_X                 46U
#define GRAPH_Y                 65U
#define GRAPH_W                 418U
#define GRAPH_H                 139U

/* Bufferes estaticos: NO colocar 1024 floats sobre la pila. */
static float signal_buffer[FFT_SIZE];
static float fft_re[FFT_SIZE];
static float fft_im[FFT_SIZE];
static float spectrum[FFT_SIZE / 2U + 1U];
static float coherent_gain = 1.0f;

typedef struct
{
  uint16_t bin;
  float amplitude;
} Peak;
static Peak peaks[3];

static const char *const case_names[CASE_COUNT] = {
  "Seno 100 Hz",
  "Cuadrada 100 Hz",
  "Triangular 100 Hz",
  "Diente sierra 100 Hz",
  "3 cuadradas 50/80/100",
  "3 senos 50/80/100",
  "Seno 103 Hz (fuga)"
};

typedef enum { SCREEN_MENU, SCREEN_RESULT } AppScreen;
static AppScreen app_screen = SCREEN_MENU;
static uint8_t menu_index = 0U;
static uint8_t active_case = 0U;
static uint8_t view_index = 0U;
static uint8_t fft_hann = 0U;
static uint8_t raw_button = 0U;
static uint8_t stable_button = 0U;
static uint32_t changed_at = 0U;
static uint32_t pressed_at = 0U;

static void App_Draw(void);
static void App_GenerateSignal(void);
static void App_ComputeFFT(void);

/* Ondas discretas de acuerdo con la guia, fase en [0,1). */
static float SignalSample(uint8_t kind, float t, float freq, float amplitude)
{
  float cyc = freq * t;
  float phase = cyc - floorf(cyc);
  switch (kind)
  {
    case 0U: return amplitude * sinf(2.0f * PI_F * phase);
    case 1U: return amplitude * ((phase < 0.5f) ? 1.0f : -1.0f);
    case 2U: return amplitude * ((phase < 0.5f) ?
                            (4.0f * phase - 1.0f) : (3.0f - 4.0f * phase));
    case 3U: return amplitude * (2.0f * phase - 1.0f);
    default: return 0.0f;
  }
}

static void App_GenerateSignal(void)
{
  for (uint32_t n = 0U; n < FFT_SIZE; ++n)
  {
    float t = ((float)n) / SAMPLE_RATE_HZ;
    switch (active_case)
    {
      case 0U: signal_buffer[n] = SignalSample(0U, t, 100.0f, 5.0f); break;
      case 1U: signal_buffer[n] = SignalSample(1U, t, 100.0f, 5.0f); break;
      case 2U: signal_buffer[n] = SignalSample(2U, t, 100.0f, 5.0f); break;
      case 3U: signal_buffer[n] = SignalSample(3U, t, 100.0f, 5.0f); break;
      case 4U:
        signal_buffer[n] = SignalSample(1U, t, 100.0f, 5.0f)
                         + SignalSample(1U, t, 50.0f, 2.0f)
                         + SignalSample(1U, t, 80.0f, 3.5f);
        break;
      case 5U:
        signal_buffer[n] = SignalSample(0U, t, 100.0f, 5.0f)
                         + SignalSample(0U, t, 50.0f, 2.0f)
                         + SignalSample(0U, t, 80.0f, 3.5f);
        break;
      default: signal_buffer[n] = SignalSample(0U, t, 103.0f, 5.0f); break;
    }
  }
}

/* FFT compleja iterativa Cooley-Tukey DIT radix-2, aplicada a entrada real.
 * Primero permutacion bit-reversal, luego etapas de mariposas. En lugar de
 * usar arm_rfft_fast_f32, este codigo mantiene la FFT autosuficiente.
 */
static void FFT_Radix2(void)
{
  uint32_t j = 0U;
  for (uint32_t i = 1U; i < FFT_SIZE; ++i)
  {
    uint32_t bit = FFT_SIZE >> 1U;
    while ((j & bit) != 0U)
    {
      j ^= bit;
      bit >>= 1U;
    }
    j ^= bit;
    if (i < j)
    {
      float tmp = fft_re[i]; fft_re[i] = fft_re[j]; fft_re[j] = tmp;
      tmp = fft_im[i]; fft_im[i] = fft_im[j]; fft_im[j] = tmp;
    }
  }
  for (uint32_t len = 2U; len <= FFT_SIZE; len <<= 1U)
  {
    float theta = -2.0f * PI_F / (float)len;
    float rot_re = cosf(theta);
    float rot_im = sinf(theta);
    uint32_t half = len >> 1U;
    for (uint32_t base = 0U; base < FFT_SIZE; base += len)
    {
      float wr = 1.0f;
      float wi = 0.0f;
      for (uint32_t k = 0U; k < half; ++k)
      {
        uint32_t p = base + k;
        uint32_t q = p + half;
        float tr = wr * fft_re[q] - wi * fft_im[q];
        float ti = wr * fft_im[q] + wi * fft_re[q];
        float ur = fft_re[p], ui = fft_im[p];
        fft_re[p] = ur + tr;
        fft_im[p] = ui + ti;
        fft_re[q] = ur - tr;
        fft_im[q] = ui - ti;
        float next_wr = wr * rot_re - wi * rot_im;
        wi = wr * rot_im + wi * rot_re;
        wr = next_wr;
      }
    }
  }
}

static void App_ComputeFFT(void)
{
  coherent_gain = 1.0f;
  if (fft_hann != 0U) coherent_gain = ((float)(FFT_SIZE - 1U)) / (2.0f * (float)FFT_SIZE);

  for (uint32_t n = 0U; n < FFT_SIZE; ++n)
  {
    float window = 1.0f; /* ventana rectangular: no altera muestras */
    if (fft_hann != 0U)
    {
      window = 0.5f - 0.5f * cosf((2.0f * PI_F * (float)n) / (float)(FFT_SIZE - 1U));
    }
    fft_re[n] = signal_buffer[n] * window;
    fft_im[n] = 0.0f;
  }
  FFT_Radix2();

  for (uint32_t k = 0U; k <= FFT_SIZE / 2U; ++k)
  {
    float factor = ((k == 0U) || (k == FFT_SIZE / 2U)) ? 1.0f : 2.0f;
    float abs_value = sqrtf(fft_re[k] * fft_re[k] + fft_im[k] * fft_im[k]);
    spectrum[k] = (factor * abs_value) / ((float)FFT_SIZE * coherent_gain);
  }

  /* Buscar los mayores picos antes de descartar vecinos proximos: de lo
   * contrario un pico debil a 98 Hz podria ocultar el principal a 100 Hz. */
  for (uint8_t p = 0U; p < 3U; ++p)
  {
    peaks[p].bin = 0U;
    peaks[p].amplitude = 0.0f;
  }
  const uint32_t max_bin = (uint32_t)(SPECTRUM_LIMIT_HZ * (float)FFT_SIZE / SAMPLE_RATE_HZ);
  for (uint8_t p = 0U; p < 3U; ++p)
  {
    for (uint32_t k = 1U; k < max_bin; ++k)
    {
      float amp = spectrum[k];
      if (amp < spectrum[k - 1U] || amp < spectrum[k + 1U] || amp < 0.025f) continue;
      uint8_t nearby = 0U;
      for (uint8_t q = 0U; q < p; ++q)
      {
        int32_t difference = (int32_t)k - (int32_t)peaks[q].bin;
        if (difference < 0) difference = -difference;
        if (difference < 3) nearby = 1U;
      }
      if ((nearby == 0U) && (amp > peaks[p].amplitude))
      {
        peaks[p].bin = (uint16_t)k;
        peaks[p].amplitude = amp;
      }
    }
  }
}

static void DrawText(uint16_t x, uint16_t y, const char *message)
{
  BSP_LCD_DisplayStringAt(x, y, (uint8_t *)message, LEFT_MODE);
}

static void DrawHeader(const char *title)
{
  BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
  BSP_LCD_Clear(LCD_COLOR_WHITE);
  BSP_LCD_SetTextColor(LCD_COLOR_DARKBLUE);
  BSP_LCD_SetFont(&Font20);
  BSP_LCD_DisplayStringAt(0U, 5U, (uint8_t *)title, CENTER_MODE);
  BSP_LCD_SetTextColor(LCD_COLOR_DARKRED);
  BSP_LCD_FillRect(12U, 30U, 456U, 2U);
  BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
  BSP_LCD_SetFont(&Font12);
}

static void DrawFooter(const char *line)
{
  BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
  BSP_LCD_SetTextColor(LCD_COLOR_DARKBLUE);
  BSP_LCD_SetFont(&Font12);
  DrawText(7U, 253U, line);
}

static void DrawMenu(void)
{
  DrawHeader("FFT - STM32F746G");
  BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
  BSP_LCD_SetFont(&Font12);
  DrawText(12U, 36U, "Elija senal / caso de prueba:");
  for (uint32_t row = 0U; row < CASE_COUNT; ++row)
  {
    uint16_t top = (uint16_t)(54U + 26U * row);
    if (row == menu_index)
    {
      BSP_LCD_SetTextColor(LCD_COLOR_DARKRED);
      BSP_LCD_FillRect(11U, top - 2U, 457U, 24U);
      BSP_LCD_SetTextColor(LCD_COLOR_WHITE);
      BSP_LCD_SetBackColor(LCD_COLOR_DARKRED);
    }
    else
    {
      BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
      BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
    }
    char buf[52];
    (void)snprintf(buf, sizeof(buf), "%c %s", row == menu_index ? '>' : ' ', case_names[row]);
    BSP_LCD_SetFont(&Font16);
    DrawText(25U, top, buf);
    BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
  }
  DrawFooter("Pulsacion corta: cambiar  |  larga: abrir");
}

static int16_t MapY(float value, float min_value, float max_value)
{
  float relative = (max_value - value) / (max_value - min_value);
  if (relative < 0.0f) relative = 0.0f;
  if (relative > 1.0f) relative = 1.0f;
  return (int16_t)(GRAPH_Y + relative * (float)GRAPH_H);
}

static void DrawGrid(void)
{
  BSP_LCD_SetTextColor(LCD_COLOR_LIGHTGRAY);
  for (uint32_t i = 0U; i <= 7U; ++i)
  {
    uint16_t xx = (uint16_t)(GRAPH_X + i * GRAPH_W / 7U);
    BSP_LCD_DrawVLine(xx, GRAPH_Y, GRAPH_H);
  }
  for (uint32_t i = 0U; i <= 5U; ++i)
  {
    uint16_t yy = (uint16_t)(GRAPH_Y + i * GRAPH_H / 5U);
    BSP_LCD_DrawHLine(GRAPH_X, yy, GRAPH_W);
  }
  BSP_LCD_SetTextColor(LCD_COLOR_DARKGRAY);
  BSP_LCD_DrawRect(GRAPH_X, GRAPH_Y, GRAPH_W, GRAPH_H);
}

static void DrawTimeSignal(void)
{
  DrawHeader("Senal en el tiempo");
  DrawText(9U, 36U, case_names[active_case]);
  DrawText(9U, 49U, "Primeras 256 muestras - Fs=2048 Hz");
  DrawGrid();
  float max_abs = 0.0f;
  for (uint32_t i = 0U; i < TIME_PLOT_SAMPLES; ++i)
  {
    float a = fabsf(signal_buffer[i]);
    if (a > max_abs) max_abs = a;
  }
  if (max_abs < 1.0f) max_abs = 1.0f;
  max_abs *= 1.1f;
  BSP_LCD_SetTextColor(LCD_COLOR_LIGHTGRAY);
  BSP_LCD_DrawHLine(GRAPH_X, (uint16_t)MapY(0.0f, -max_abs, max_abs), GRAPH_W);
  BSP_LCD_SetTextColor(LCD_COLOR_DARKRED);
  for (uint32_t i = 1U; i < TIME_PLOT_SAMPLES; ++i)
  {
    int16_t x1 = (int16_t)(GRAPH_X + ((i - 1U) * (GRAPH_W - 1U)) / (TIME_PLOT_SAMPLES - 1U));
    int16_t x2 = (int16_t)(GRAPH_X + (i * (GRAPH_W - 1U)) / (TIME_PLOT_SAMPLES - 1U));
    BSP_LCD_DrawLine(x1, MapY(signal_buffer[i-1U], -max_abs, max_abs),
                     x2, MapY(signal_buffer[i], -max_abs, max_abs));
  }
  BSP_LCD_SetTextColor(LCD_COLOR_DARKGRAY);
  DrawText(46U, 208U, "0 ms"); DrawText(405U, 208U, "125 ms");
  char line[64];
  (void)snprintf(line, sizeof(line), "Maximo aproximado: %ld.%02ld unidades",
                 (long)max_abs, (long)((max_abs - (float)((long)max_abs))*100.0f));
  DrawText(9U, 232U, line);
  DrawFooter("Corta: siguiente vista  |  larga: menu");
}

static void DrawSpectrum(void)
{
  DrawHeader((fft_hann != 0U) ? "FFT - ventana Hann" : "FFT - rectangular");
  DrawText(9U, 36U, case_names[active_case]);
  DrawText(9U, 49U, "N=1024 | Fs=2048Hz | df=2Hz");
  DrawGrid();
  /* Amplitudes normalizadas a la amplitud de la senal (no dB). */
  for (uint32_t k = 1U; k <= (uint32_t)(SPECTRUM_LIMIT_HZ / 2.0f); ++k)
  {
    float hz = 2.0f * (float)k;
    uint16_t x = (uint16_t)(GRAPH_X + (uint32_t)((hz / SPECTRUM_LIMIT_HZ) * (float)(GRAPH_W - 1U)));
    float value = spectrum[k];
    if (value > 10.0f) value = 10.0f;
    uint16_t y = (uint16_t)MapY(value, 0.0f, 10.0f);
    BSP_LCD_SetTextColor(LCD_COLOR_DARKRED);
    if (y < GRAPH_Y + GRAPH_H) BSP_LCD_DrawVLine(x, y, (uint16_t)(GRAPH_Y + GRAPH_H - y));
  }
  BSP_LCD_SetTextColor(LCD_COLOR_DARKGRAY);
  BSP_LCD_SetFont(&Font12);
  for (uint32_t i = 0U; i <= 7U; ++i)
  {
    char label[12];
    (void)snprintf(label, sizeof(label), "%lu", (unsigned long)(50U * i));
    DrawText((uint16_t)(GRAPH_X + (i * (GRAPH_W - 1U)) / 7U), 208U, label);
  }
  DrawText(12U, 63U, "10"); DrawText(18U, 186U, "0");
  DrawText(353U, 232U, "Freq [Hz]");
  if (peaks[0].amplitude > 0.0f)
  {
    char line[64];
    (void)snprintf(line, sizeof(line), "Pico: %lu Hz   A=%ld.%02ld",
      (unsigned long)(peaks[0].bin * 2U), (long)peaks[0].amplitude,
      (long)((peaks[0].amplitude - (float)((long)peaks[0].amplitude)) * 100.0f));
    DrawText(9U, 232U, line);
  }
  DrawFooter("Corta: siguiente vista  |  larga: menu");
}

static void DrawDiagnostics(void)
{
  DrawHeader("Analisis espectral");
  BSP_LCD_SetFont(&Font16);
  BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
  DrawText(12U, 42U, case_names[active_case]);
  BSP_LCD_SetFont(&Font12);
  DrawText(12U, 76U, "Espectro unilateral, amplitud lineal");
  DrawText(12U, 97U, (fft_hann != 0U) ? "Ventana: Hann (ganancia corregida)" : "Ventana: rectangular (sin multiplicar)");
  DrawText(12U, 116U, "N=1024, Fs=2048 Hz, Delta f = 2 Hz");
  DrawText(12U, 142U, "3 componentes espectrales mas intensas:");
  for (uint8_t i = 0U; i < 3U; ++i)
  {
    char line[64];
    float amplitude = peaks[i].amplitude;
    if (amplitude <= 0.0f)
      (void)snprintf(line, sizeof(line), "%u. Sin pico adicional", (unsigned)(i+1U));
    else
      (void)snprintf(line, sizeof(line), "%u. f=%lu Hz     A=%ld.%03ld",
        (unsigned)(i + 1U), (unsigned long)(peaks[i].bin * 2U),
        (long)amplitude, (long)((amplitude - (float)((long)amplitude))*1000.0f));
    DrawText(22U, (uint16_t)(164U + 22U * i), line);
  }
  DrawFooter("Corta: siguiente vista  |  larga: menu");
}

static void App_Draw(void)
{
  if (app_screen == SCREEN_MENU) { DrawMenu(); return; }
  switch (view_index)
  {
    case 0U: DrawTimeSignal(); break;
    case 1U: fft_hann = 0U; App_ComputeFFT(); DrawSpectrum(); break;
    case 2U: fft_hann = 1U; App_ComputeFFT(); DrawSpectrum(); break;
    default: DrawDiagnostics(); break;
  }
}

static void App_Init(void)
{
  BSP_PB_Init(BUTTON_KEY, BUTTON_MODE_GPIO);
  BSP_LED_Init(LED1);
  BSP_LED_Off(LED1);
  app_screen = SCREEN_MENU;
  menu_index = 0U;
  changed_at = HAL_GetTick();
  raw_button = (BSP_PB_GetState(BUTTON_KEY) == GPIO_PIN_RESET) ? 1U : 0U;
  stable_button = raw_button;
  App_Draw();
}

static void App_ButtonEvent(uint8_t long_press)
{
  if (app_screen == SCREEN_MENU)
  {
    if (long_press != 0U)
    {
      active_case = menu_index;
      app_screen = SCREEN_RESULT;
      view_index = 0U;
      fft_hann = 0U;
      App_GenerateSignal();
      App_ComputeFFT();
      BSP_LED_On(LED1);
    }
    else menu_index = (uint8_t)((menu_index + 1U) % CASE_COUNT);
  }
  else
  {
    if (long_press != 0U)
    {
      app_screen = SCREEN_MENU;
      BSP_LED_Off(LED1);
    }
    else view_index = (uint8_t)((view_index + 1U) % VIEW_COUNT);
  }
  App_Draw();
}

static void App_Update(uint32_t time_ms)
{
  /* USER/KEY: estado activo bajo, igual al proyecto de referencia. */
  uint8_t reading = (BSP_PB_GetState(BUTTON_KEY) == GPIO_PIN_RESET) ? 1U : 0U;
  if (reading != raw_button)
  {
    raw_button = reading;
    changed_at = time_ms;
  }
  if ((reading != stable_button) && ((uint32_t)(time_ms - changed_at) >= DEBOUNCE_MS))
  {
    stable_button = reading;
    if (reading != 0U) pressed_at = time_ms;
    else App_ButtonEvent((uint8_t)(((uint32_t)(time_ms - pressed_at)) >= HOLD_MS));
  }
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MPU Configuration--------------------------------------------------------*/
  MPU_Config();

  /* La región de framebuffer LCD está marcada no-cacheable en MPU; así se
     activan las cachés sin perder coherencia con LTDC. */
  SCB_EnableICache();
  SCB_EnableDCache();

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();
  startup_stage = 1U;

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  /* FFT de senales sinteticas: no se inicializa ADC1. */
  startup_stage = 2U;
  /* USER CODE BEGIN 2 */
  lcd_init_status = BSP_LCD_Init();
  if (lcd_init_status != LCD_OK)
  {
    startup_stage = 0xE1U;
    Error_Handler();
  }
  startup_stage = 3U;
  BSP_LCD_LayerDefaultInit(0, LCD_FB_START_ADDRESS);
  BSP_LCD_SelectLayer(0);
  /* Paint the framebuffer directly first, so the initial LCD test does not
     depend on DMA2D being configured correctly. */
  volatile uint32_t *framebuffer = (volatile uint32_t *)LCD_FB_START_ADDRESS;
  for (uint32_t pixel = 0U; pixel < (480U * 272U); pixel++)
  {
    framebuffer[pixel] = LCD_COLOR_WHITE;
  }
  BSP_LCD_SetLayerVisible(0, ENABLE);
  BSP_LCD_DisplayOn();
  BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
  BSP_LCD_SetTextColor(LCD_COLOR_BLACK);
  App_Init();
  startup_stage = 4U;

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    App_Update(HAL_GetTick());
    HAL_Delay(10U);

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 432;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_7) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
/* No son necesarias interrupciones de ADC. */
/* USER CODE END 4 */

 /* MPU Configuration */

void MPU_Config(void)
{
  MPU_Region_InitTypeDef MPU_InitStruct = {0};

  /* Disables the MPU */
  HAL_MPU_Disable();

  /** Initializes and configures the Region and the memory to be protected
  */
  MPU_InitStruct.Enable = MPU_REGION_ENABLE;
  MPU_InitStruct.Number = MPU_REGION_NUMBER0;
  MPU_InitStruct.BaseAddress = 0x0;
  MPU_InitStruct.Size = MPU_REGION_SIZE_4GB;
  MPU_InitStruct.SubRegionDisable = 0x87;
  MPU_InitStruct.TypeExtField = MPU_TEX_LEVEL0;
  MPU_InitStruct.AccessPermission = MPU_REGION_NO_ACCESS;
  MPU_InitStruct.DisableExec = MPU_INSTRUCTION_ACCESS_DISABLE;
  MPU_InitStruct.IsShareable = MPU_ACCESS_SHAREABLE;
  MPU_InitStruct.IsCacheable = MPU_ACCESS_NOT_CACHEABLE;
  MPU_InitStruct.IsBufferable = MPU_ACCESS_NOT_BUFFERABLE;

  HAL_MPU_ConfigRegion(&MPU_InitStruct);

  /* Keep the LCD framebuffer in SDRAM non-cacheable for reliable display. */
  MPU_InitStruct.Enable = MPU_REGION_ENABLE;
  MPU_InitStruct.Number = MPU_REGION_NUMBER1;
  MPU_InitStruct.BaseAddress = 0xC0000000;
  MPU_InitStruct.Size = MPU_REGION_SIZE_8MB;
  MPU_InitStruct.SubRegionDisable = 0x00;
  MPU_InitStruct.TypeExtField = MPU_TEX_LEVEL0;
  MPU_InitStruct.AccessPermission = MPU_REGION_FULL_ACCESS;
  MPU_InitStruct.DisableExec = MPU_INSTRUCTION_ACCESS_DISABLE;
  MPU_InitStruct.IsShareable = MPU_ACCESS_SHAREABLE;
  MPU_InitStruct.IsCacheable = MPU_ACCESS_NOT_CACHEABLE;
  MPU_InitStruct.IsBufferable = MPU_ACCESS_NOT_BUFFERABLE;
  HAL_MPU_ConfigRegion(&MPU_InitStruct);

  /* The default no-access MPU region covers FMC registers at 0xA0000000.
     Allow the FMC controller to initialize the Discovery SDRAM. */
  MPU_InitStruct.Enable = MPU_REGION_ENABLE;
  MPU_InitStruct.Number = MPU_REGION_NUMBER2;
  MPU_InitStruct.BaseAddress = 0xA0000000;
  MPU_InitStruct.Size = MPU_REGION_SIZE_1MB;
  MPU_InitStruct.SubRegionDisable = 0x00;
  MPU_InitStruct.TypeExtField = MPU_TEX_LEVEL0;
  MPU_InitStruct.AccessPermission = MPU_REGION_FULL_ACCESS;
  MPU_InitStruct.DisableExec = MPU_INSTRUCTION_ACCESS_DISABLE;
  MPU_InitStruct.IsShareable = MPU_ACCESS_SHAREABLE;
  MPU_InitStruct.IsCacheable = MPU_ACCESS_NOT_CACHEABLE;
  MPU_InitStruct.IsBufferable = MPU_ACCESS_NOT_BUFFERABLE;
  HAL_MPU_ConfigRegion(&MPU_InitStruct);

  /* Enables the MPU */
  HAL_MPU_Enable(MPU_PRIVILEGED_DEFAULT);

}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  startup_stage = 0xEEU;
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
